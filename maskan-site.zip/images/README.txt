DROP YOUR PHOTOS HERE
=====================

The landing page currently uses SVG scenes as stand-ins for photography.
To swap in a real photo, open index.html, find the line for that slot near
the bottom (they all start with `scene("sc-`), and replace it:

  scene("sc-hero", towers("#2B1512","#7A3A18","#170100","#E8A94E"));

becomes:

  document.getElementById("sc-hero").innerHTML =
    '<img src="images/hero.jpg" alt="">';

The container is already set to object-fit: cover, so any aspect ratio works.

SLOTS AND WHAT SUITS THEM
  sc-hero      Full-bleed hero. West Bay or Lusail skyline, golden hour.
               Portrait or landscape, min 2000px wide.
  sc-collect   "collect" panel. An office interior, someone at a desk.
  sc-protect   "protect" panel. A residential tower exterior.
  sc-control   "control" panel. A villa compound or low-rise development.
  sc-why       "why" panel, left-scrimmed. Aerial of a development.
  sc-cta       Closing CTA. Skyline at dusk works well.
  sc-s1/s2/s3  The three numbered steps. 4:3 crops.

WHERE TO GET THEM
  Unsplash (unsplash.com) and Pexels (pexels.com) are free for commercial
  use with no attribution required. Search "Doha", "West Bay Qatar",
  "Lusail", "Middle East apartment interior".

  Adobe Stock works too, but needs a paid licence per image.

  Do NOT use Pinterest. Those are other people's copyrighted photographs
  indexed from elsewhere — using them commercially is infringement, and
  hotlinked Pinterest URLs break without warning.

Downloaded files go in this folder, then reference them as images/name.jpg
