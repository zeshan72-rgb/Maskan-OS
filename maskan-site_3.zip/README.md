# Maskan

Two static HTML files. No build step, no dependencies, no server.

```
index.html     Landing page
app.html       Interactive demo, ~70 screens
vercel.json    Security headers and clean URLs
```

---

## Deploy

Any static host works. Drag the folder into Vercel, Netlify or Cloudflare
Pages and it runs as-is.

**Vercel CLI**

```
vercel --prod
```

`cleanUrls` is on, so `app.html` is served at `/app`. That matches the links
already in the landing page.

**Testing locally** — open `index.html` directly, or run a server if you want
the clean URLs to behave the same as production:

```
python3 -m http.server 8000
```

---

## The demo links

Every "Open the demo" button on the landing page points at:

```
https://rentos-blue.vercel.app/app#dashboard
```

Nine links in total. Six go to the dashboard; three deep-link to the tenant,
owner and contractor portals from the footer. All open in a new tab with
`rel="noopener"`.

**If you deploy both files to the same domain**, swap the absolute URLs for
relative ones so the site stops depending on the old deployment:

```
find . -name '*.html' -exec sed -i '' 's|https://rentos-blue.vercel.app/app|/app|g' {} +
```

Drop the `''` after `-i` on Linux.

---

## Before this goes public

**Self-host the fonts.** Archivo and Inter Tight are currently pulled from
Google Fonts. The brand kit asks for self-hosted woff2 files, which is also
faster and avoids a third-party request on every page load.

**Point the domain.** The kit uses `maskan.qa`. The footer and all `mailto:`
links already use `hello@maskan.qa`.

**Decide what happens after the demo.** Right now every path ends inside the
demo and the trail goes cold. A form, a Calendly link or a monitored inbox
would close that loop.

**Redirect anything published as RentOS.** The product was renamed to Maskan;
neither file contains the old name.

---

## What the site claims, and does not

The landing page states plainly that this is a working prototype with sample
data. It does not claim a backend, and the compliance section says outright
that Maskan assembles a registration pack but files nothing with any
government service and connects to no official API.

Keep that language if you edit the copy. It is the difference between a
prospect trusting the rest of the page and not.

---

## Landing page structure

| Section | Ground | Notes |
| --- | --- | --- |
| Hero | Ink | Cheque ledger, rows settle on load, total counts up |
| What Maskan replaces | Paper | Five old systems, each paired with the screen replacing it |
| From cheque to cleared | Ink | Register plus four lifecycle stages, synced |
| The product | Paper | Four portals, tab-switched, real screens |
| Moving in | Paper | Migration reconciliation, one deliberate discrepancy |
| Compliance | Paper | Document readiness, with the honest limitation |
| Questions | Paper | Three |
| Close | Ink | Owner statement assembles, net figure resolves |

Interactive: 4 lifecycle stages, 5 before/after panes, 4 portal tabs, 3 FAQs.
Each auto-advances until clicked, then hands control over permanently.

Responsive at 1024 / 832 / 672 / 512px, plus `prefers-reduced-motion`,
`prefers-reduced-transparency` and `prefers-contrast`.
